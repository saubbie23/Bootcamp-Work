from flask import Flask, render_template, redirect, session, request
from random import randint, uniform

app = Flask(__name__)

def randGold(building):
    if building == 'farm':
        gold = randint(10,20)
    elif building == 'cave':
        gold = randint(5,10)
    elif building == 'house':
        gold = randint(2,5)
    else:
        gold = uniform(-50,50)            
    return gold

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process_money', methods=['POST'])
def process_money():
    print(request.form)

    if 'gold' not in session:
        session['gold'] = 0
    else:
        session['gold'] = session['gold'] + randGold(request['building'])    
    return redirect('/')


if __name__ == '__main__':
    app.run(debug=True)